ServerEvents.recipes(event => {
  // Remove the old tuff recipe (compacting with 16 cobblestone + water)
  event.remove({ output: 'minecraft:tuff', type: 'create:compacting' })

  // Add a new, cheaper version: 4 cobblestone + 100mb water
  event.custom({
    type: 'create:compacting',
    ingredients: [
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      { item: 'minecraft:cobblestone' },
      { type: "fluid_stack", fluid: 'minecraft:water', amount: 100 }
    ],
    results: [
      { id: 'minecraft:tuff' }
    ]
  })

  event.remove({ type: 'create:crushing', input: 'minecraft:tuff' })

  // Add new crushing recipe with 35% chance for all outputs
  event.custom({
    type: "create:crushing",
    ingredients: [
      { item: "minecraft:tuff" }
    ], 
    processingTime: 200,
    results: [
      { id: 'minecraft:flint', chance: 0.50 },
      { id: 'minecraft:gold_nugget', chance: 0.35 },
      { id: 'create:copper_nugget', chance: 0.35 },
      { id: 'create:zinc_nugget', chance: 0.35 },
      { id: 'minecraft:iron_nugget', chance: 0.35 },
    ]
  })
})