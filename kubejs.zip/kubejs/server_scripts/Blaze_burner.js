ServerEvents.recipes(event => {
    event.custom({
        type: "create:filling",
        ingredients: [
        { item: "create:empty_blaze_burner" },
        { type: "fluid_stack", fluid: "minecraft:lava", amount: 1000 }
        ],
        results: [
        { id: "create:blaze_burner", count: 1 },
        ]

    })
})