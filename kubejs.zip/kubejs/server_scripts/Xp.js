ServerEvents.recipes(event => {
event.custom({
        type: "create:crushing",
        ingredients: [
        { item: "minecraft:quartz" }
        ],
        "processing_time": 250,
        results: [
        { id: "create:experience_nugget" },
        { id: "create:experience_nugget", chance: 0.20 },
        ]

    })
})