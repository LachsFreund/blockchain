ServerEvents.recipes(event => {
    
    event.remove({ output: 'minecraft:flint', type: 'create:splashing' })
    
    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:gravel"},
        ],
        results: [
        { id: "minecraft:flint", chance: 0.35 },
        { id: "minecraft:iron_nugget", chance: 0.25 },
        ]

    })
})