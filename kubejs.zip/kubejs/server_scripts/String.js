ServerEvents.recipes(event => {
    event.custom({
        type: "create:pressing",
        ingredients: [
        { tag: "minecraft:leaves" },
       ],
        results: [
        { id: "minecraft:string", count: 1 },
        ]

    })
})