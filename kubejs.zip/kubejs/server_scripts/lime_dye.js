ServerEvents.recipes(event => {
    event.custom({
        type: "create:crushing",
        ingredients: [
            { tag: "create:pulpifiable" }
        ], 
        processingTime: 200,
        results: [
            { id: 'minecraft:lime_dye'},
            { id: 'minecraft:green_dye', chance: 0.3 },
            { id: 'minecraft:stick', chance: 0.1 }
        ]
    })
})