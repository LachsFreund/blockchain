ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        ingredients: [
        { item: "minecraft:netherrack" },
        { item: "minecraft:flint" },
        { type: "fluid_stack", fluid: "minecraft:lava", amount: 250 }
        ],
        results: [
        { id: "minecraft:redstone", count: 1 },
        ]

    })
})