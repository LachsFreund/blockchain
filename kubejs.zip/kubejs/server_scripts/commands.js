ServerEvents.basicCommand('shop', event => {
  if (!event.player) return; // Nur im Spiel ausführbar
    event.server.runCommandSilent(`/tp @p 243 313 -388`);
});

ServerEvents.basicCommand('home', event => {
  if (!event.player) return; // Nur im Spiel ausführbar
    event.server.runCommandSilent(`/tp @p 180 61 -413`);
});

PlayerEvents.loggedIn(event => {
  const player = event.player;
  const persistentData = player.persistentData;

  if (!persistentData.hasGivenLava) {
    // Nur beim ersten Login
    persistentData.hasGivenLava = true;

    event.server.runCommandSilent(`tellraw @a {"text":"Benutze /home um nach Hause zu kommen, und /shop für den shop","color":"gold"}`);
  }
});