ServerEvents.recipes(event => {
    event.remove({ output: 'create:brass_casing', type: 'create:item_application' })
    event.remove({ output: 'create:copper_casing', type: 'create:item_application' })
    event.remove({ output: 'create:railway_casing', type: 'create:item_application' })
    
    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:andesite_casing" },
            { item: "minecraft:copper_ingot" },   
        ],
        results: [
            { id: "create:copper_casing" },
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:andesite_casing" },
            { item: "create:brass_ingot" },   
        ],
        results: [
            { id: "create:brass_casing" },
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { item: "create:brass_casing" },
            { item: "create:sturdy_sheet" },   
        ],
        results: [
            { id: "create:railway_casing" },
        ]
    })
})