ServerEvents.recipes(event => {
    event.custom({
        type: "create:pressing",
        ingredients: [
        { "tag": "create:pulpifiable" },
       ],
        results: [
        { id: "minecraft:paper", count: 1 },
        ]

    })
})