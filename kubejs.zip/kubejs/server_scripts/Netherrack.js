ServerEvents.recipes(event => {
    event.custom({
        type: "create:haunting",
        ingredients: [
        { item: "minecraft:basalt" }
       ],
        results: [
        { id: "minecraft:netherrack"}
        ]
    })
})