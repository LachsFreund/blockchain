ServerEvents.recipes(event => {
    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:snowball"},
        ],
        results: [
        { id: "minecraft:ice" },
        ]

    })

    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:ice"},
        ],
        results: [
        { id: "minecraft:packed_ice" },
        ]

    })

    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:packed_ice"},
        ],
        results: [
        { id: "minecraft:blue_ice" },
        ]

    })
})